#include "ckernel.h"
#include"qDebug"

//通过宏定义化简
#define NetMap(x)  m_netMap[ x - _DEF_PROTOCOL_BASE ]


//协议映射关系
void CKernel::setNetMap()
{
    memset( m_netMap , 0 , sizeof(PFUN ));

//    m_netMap[ _DEF_PACK_LOGIN_RS - _DEF_PROTOCOL_BASE ] = &CKernel::slot_dealLoginRs;
    NetMap(_DEF_PACK_LOGIN_RS) = &CKernel::slot_dealLoginRs;
}
#include<QSettings>
#include<QApplication>
#include<QFileInfo>
//初始化配置
void CKernel::initConfig()
{
    m_serverIP = _DEF_SERVER_IP;
    // 路径设置  exe 同级的目录下 -> applicationDirPath config.ini
    QString path = QApplication::applicationDirPath() + "/config.ini";
    //判断是否存在
    QFileInfo info( path );
    QSettings settings( path , QSettings::IniFormat , NULL ); // 有打开 没有创建
    if( info.exists() ){
    //加载配置文件 ip  如配置文件 设置为配置文件中的ip
        //打开配置文件
        //移动到 Net 组
        settings.beginGroup( "Net");
        //读取 ip -> addr --> 赋值
        QVariant ip = settings.value( "ip" );
        QString strIP = ip.toString();
        //结束
        settings.endGroup();
        if( !strIP.isEmpty() ){
            m_serverIP = strIP;
        }
    }else{
    //没有配置文件 写入默认的ip
        settings.beginGroup( "Net");
        settings.setValue( "ip" , m_serverIP );
        settings.endGroup();
    }
    qDebug() << m_serverIP;
}


CKernel::CKernel(QObject *parent) : QObject(parent)
{
    //设置协议映射关系
    setNetMap();
    initConfig();

    m_loginDialog   = new LoginDialog;
    m_demoDialog    = new DemoDialog;

    m_client        = new TcpClientMediator;
    connect( m_client , SIGNAL(SIG_ReadyData(uint,char*,int))
             , this , SLOT( slot_dealData(uint,char*,int)) );

    connect( m_loginDialog , SIGNAL(SIG_close())
             ,this , SLOT(slot_destroy()) );

    connect( m_demoDialog , SIGNAL(SIG_close())
             ,this , SLOT(slot_destroy()) );

    m_client->OpenNet( m_serverIP.toStdString().c_str() );

    m_loginDialog->show();


    //测试 登录 验证与服务器的链接
    STRU_LOGIN_RQ rq;
    strcpy( rq.tel , "123" );
    strcpy( rq.password , "123");

    m_client->SendData( 0 , (char*)&rq , sizeof(rq) );

}

CKernel::~CKernel()
{
    //    slot_destroy();
}



void CKernel::slot_destroy()
{
    qDebug() << __func__;

    if( m_loginDialog ){
        m_loginDialog->hide(); //不写close 不然会触发关闭事件会死循环
        delete m_loginDialog; m_loginDialog = NULL;
    }
    if( m_demoDialog ){
        m_demoDialog->hide();
        delete m_demoDialog; m_demoDialog = NULL;
    }
    if( m_client ){
        m_client->CloseNet();
        delete m_client; m_client = NULL;
    }
}

void CKernel::slot_dealData(uint socket, char *buf, int nlen)
{
    //协议映射表
    int type = *(int*)buf;
    if( type >= _DEF_PROTOCOL_BASE && type < _DEF_PROTOCOL_BASE + _DEF_PROTOCOL_COUNT )
    {
        PFUN pf = NetMap(type);
        if( pf )
            (this->*pf)( socket , buf , nlen );
    }

    delete[] buf;
}

void CKernel::slot_dealLoginRs(uint socket, char *buf, int nlen)
{
    qDebug() << __func__;

}

void CKernel::slot_clientSendData(uint socket, char *buf, int nlen)
{
    m_client->SendData( socket , buf , nlen );
}


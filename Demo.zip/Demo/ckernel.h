#ifndef CKERNEL_H
#define CKERNEL_H

#include <QObject>
#include "logindialog.h"
#include "demodialog.h"
#include "TcpClientMediator.h"
#include "packdef.h"

class CKernel;
typedef void (CKernel::*PFUN)(uint socket,char* buf,int nlen);

//单例
class CKernel : public QObject
{
    Q_OBJECT
private:
    explicit CKernel(QObject *parent = nullptr);
    ~CKernel();
    CKernel( const CKernel& kernel){}

signals:

public:
    static CKernel* getInstance()
    {
        static CKernel kernel;
        return &kernel;
    }
public slots:
    //设置协议映射关系
    void setNetMap();
    //初始化配置
    void initConfig();

    //回收
    void slot_destroy();
    //网络处理
    void slot_dealData(uint socket,char* buf,int nlen);

    //网络处理函数
    void slot_dealLoginRs(uint socket,char* buf,int nlen);

    //客户端发送数据
    void slot_clientSendData( uint socket,char* buf,int nlen );
private:
    PFUN            m_netMap[_DEF_PROTOCOL_COUNT];
    LoginDialog*    m_loginDialog;
    DemoDialog*     m_demoDialog;
    INetMediator*   m_client;
    QString         m_serverIP;
};

#endif // CKERNEL_H
